# Gourav Blog (JSP) — Railway Deploy

This is a JSP + Servlet application deployed on Railway using Docker + Tomcat.

## Deployment Steps

1. Upload this folder to a GitHub repo
2. Go to Railway -> New Project -> Deploy from GitHub
3. Railway auto-builds using Dockerfile

Your site will run at:

https://your-app.up.railway.app/
